#!/usr/bin/env python
import sys

sys.stdout.write('Hello from my script! This is recently added.\n')